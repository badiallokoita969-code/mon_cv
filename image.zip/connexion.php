<?php
try {
    $pdo = new PDO("mysql:host=localhost;dbname=mon_cv;charset=utf8", "root", ""); // change le mot de passe si besoin
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}
?>